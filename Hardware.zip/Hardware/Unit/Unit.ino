#include <OneWire.h>
#include <DallasTemperature.h>
#define ONE_WIRE_BUS 2
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);
String phoneNumber = "+94710648487";   
String messageText = "Hello from Arduino Nano";
float waterTempC = 0;
void sendSms(){
  Serial.println("AT+CMGF=1");
  delay(1000);
  Serial.println("AT+CSCS=\"GSM\"");
  delay(1000);
  Serial.println("AT+CMGS=\"+94710648487\"");
  delay(1000);
  messageText = "{\"waterTemp\":"+String(waterTempC)+"}$";
  Serial.print(messageText);
  delay(500);
  Serial.write(26); 
}
void getWaterTemp(){
  sensors.requestTemperatures(); 
  waterTempC = sensors.getTempCByIndex(0);
}
void setup() {
  Serial.begin(9600); 
  sensors.begin();   
  getWaterTemp();
  sendSms();
}

void loop() {
  

}
