#include <Wire.h>

#define SHT30_ADDR 0x44

void setup() {
  Serial.begin(9600);
  Wire.begin();
}

void loop() {

  Wire.beginTransmission(SHT30_ADDR);
  Wire.write(0x2C);
  Wire.write(0x06);
  Wire.endTransmission();

  delay(500);

  Wire.requestFrom(SHT30_ADDR, 6);

  if(Wire.available()==6)
  {
    uint16_t temp_raw = Wire.read()<<8 | Wire.read();
    Wire.read(); // CRC

    uint16_t hum_raw = Wire.read()<<8 | Wire.read();
    Wire.read(); // CRC

    float temperature = -45 + (175 * (temp_raw / 65535.0));
    float humidity = 100 * (hum_raw / 65535.0);

    Serial.print("Temperature: ");
    Serial.print(temperature);
    Serial.println(" C");

    Serial.print("Humidity: ");
    Serial.print(humidity);
    Serial.println(" %");

    Serial.println();
  }

  delay(2000);
}
